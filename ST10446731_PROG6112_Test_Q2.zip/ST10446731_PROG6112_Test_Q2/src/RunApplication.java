class RunApplication {
    public static void main(String[] args) {

        RoadAccidentsReport printAccidentReport = new ReportAccidentReport();


    }
}
