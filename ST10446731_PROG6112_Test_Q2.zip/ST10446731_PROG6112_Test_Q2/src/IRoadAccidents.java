public interface IRoadAccidents { //creating the interface
    String getAccidentVehicleType();
    double getCity();
    double getAccidentTotal();
}
