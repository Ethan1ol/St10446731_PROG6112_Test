import java.util.Scanner;

public abstract class RoadAccidents {
        private String vehicleType; //creating private values
        private String city;
        private int numberOfAccidents;

        public RoadAccidents(String vehicleType, String city, int numberOfAccidents){
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter the type of vehicle in the accident: ");
            vehicleType = scanner.next();

            System.out.print("Enter the city in which the accident occurred: ");
            city = scanner.next();

            System.out.println("What is the total amount of accidents in the city");
            numberOfAccidents = scanner.nextInt();


            this.vehicleType = vehicleType;
            this.city = city;
            this.numberOfAccidents = numberOfAccidents;
        }

        public String getvehicleType(){
            return vehicleType;
        }

        public String getCity(){
            return city;
        }
        public int getAccidentTotal(){
            return numberOfAccidents;
        }


        }


