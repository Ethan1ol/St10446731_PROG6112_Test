public class RoadAccidentReport extends RoadAccidents{

    public RoadAccidentReport(String vehicleType, String city, int numberOfAccidents) {
        super(vehicleType, city, numberOfAccidents); // getting the values from the super class
    }
    void printAccidentReport(){
       System.out.println("VEHICLE ACCIDENT REPORT"); // Printing out the vehicle report
        System.out.println("*******************");
        System.out.println(" VEHICLE TYPE :" + getCity() );
        System.out.println(" VEHICLE TYPE :" + getvehicleType() );

        System.out.println(" VEHICLE TYPE :" + getAccidentTotal() );

    }
}
