import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

       Scanner scanner = new Scanner(System.in);
        int [][] roadAccidents = new int[3][2];
        String[] City = {"Cape Town" , "Johannesburg", "Port Elizabeth"};

        System.out.println("Enter the number of car accidents for Cape Town : ");
        roadAccidents[0][0] = Integer.parseInt(scanner.nextLine());

        System.out.println("Enter the number of motor bike accidents for Cape Town : ");
        roadAccidents[0][1] = Integer.parseInt(scanner.nextLine());

        System.out.println("Enter the number of car accidents for Johannesburg : ");
        roadAccidents[1][0] = Integer.parseInt(scanner.nextLine());

        System.out.println("Enter the number of motor bike accidents for Johannesburg : ");
        roadAccidents[1][1] = Integer.parseInt(scanner.nextLine());

        System.out.println("Enter the number of car accidents for Port Elizabeth : ");
        roadAccidents[2][0] = Integer.parseInt(scanner.nextLine());

        System.out.println("Enter the number of motor bike accidents for Cape Town : ");
        roadAccidents[2][1] = Integer.parseInt(scanner.nextLine());

        System.out.println("-------------------------------------------------------------------");
        System.out.println("Road Accident Report");
        System.out.println("-------------------------------------------------------------------");
        System.out.println("Car \t MOTOR BIKE");

        for(int i = 0 ;i < roadAccidents.length;i++ ){
         int total =0;
         System.out.print("City" + (i+1)+":");
         for (int j = 0 ; j < roadAccidents[i].length;i++ ){
          total += roadAccidents[i][j];
          System.out.print(roadAccidents[i][j] + " ");
         }

         }
        }







    }
